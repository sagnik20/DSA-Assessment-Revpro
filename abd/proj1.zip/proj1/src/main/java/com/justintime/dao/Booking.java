package com.justintime.dao;

/**
 * @author Sagnik
 *
 */

public interface Booking {
	
	boolean requestCab();

}
