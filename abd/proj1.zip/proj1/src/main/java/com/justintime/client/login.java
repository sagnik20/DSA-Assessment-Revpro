package com.justintime.client;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
/**
 * @author Sagnik
 *
 */

public class login extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String id=request.getParameter("id");
		String pwd=request.getParameter("ipass");
		Integer dropdown = Integer.parseInt(request.getParameter("dropdown"));
		//out.println(dropdown + " "+ id + " " + pwd);
		
		switch(dropdown) {
		case 1:{
			//Employee
			if(id.equalsIgnoreCase("employee") && pwd.equalsIgnoreCase("employee")) {
				HttpSession s=request.getSession(true);
				s.setAttribute("id",id);
				s.setAttribute("pass", pwd);
				RequestDispatcher rd=request.getRequestDispatcher("Employee.html");
				rd.include(request, response);
			}
			break;
		}
		case 2:{
			//Manager
			if(id.equalsIgnoreCase("manager") && pwd.equalsIgnoreCase("manager")) {
				HttpSession s=request.getSession(true);
				s.setAttribute("id",id);
				s.setAttribute("pass", pwd);
				RequestDispatcher rd=request.getRequestDispatcher("Manager.html");
				rd.include(request, response);
			}
			break;
		}
		case 3:{
			//Admin
			if(id.equalsIgnoreCase("admin") && pwd.equalsIgnoreCase("admin")) {
				HttpSession s=request.getSession(true);
				s.setAttribute("id",id);
				s.setAttribute("pass", pwd);
				RequestDispatcher rd=request.getRequestDispatcher("Admin.html");
				rd.include(request, response);
			}
			break;
		}
			
		}
	}

}
