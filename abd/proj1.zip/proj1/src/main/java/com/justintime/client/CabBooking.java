package com.justintime.client;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.justintime.dao.HibernateCon;
import com.justintime.model.Employee;

/**
 * @author Sagnik
 *
 */

public class CabBooking extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		out.println("Welcome to Cab booking");
		out.println("Here Employee books a cab");
		out.print("<form> </form>");
		//HttpSession s=request.getSession(true);
		//String id = (String)(s.getAttribute("id"));
		HibernateCon sf = new HibernateCon();
		Session session = sf.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		Integer a = 2;
		Employee manager = (Employee) session.load(Employee.class, a);
		manager.setManager(1);
		session.update(manager);
		session.flush();

		   
		tx.commit();
		session.close();
		
	}

}
