package com.justintime.service;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.justintime.model.Employee;

/**
 * @author Sagnik
 *
 */

public class EmployeeRegistration extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("Redirected after Employee Registration details");
		
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String dept = request.getParameter("dept");
		
		Employee emp = new Employee(name,email,1,dept);
		
		out.println("Send Employee object to database");
	}

}
