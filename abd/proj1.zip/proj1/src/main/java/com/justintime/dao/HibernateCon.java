package com.justintime.dao;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 * @author Sagnik
 *
 */

public class HibernateCon {
	
	public static SessionFactory getSessionFactory() {
		SessionFactory sf = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
		
		return sf;
	}

}
